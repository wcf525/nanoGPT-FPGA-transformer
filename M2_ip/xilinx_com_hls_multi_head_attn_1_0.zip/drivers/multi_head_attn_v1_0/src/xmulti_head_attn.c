// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmulti_head_attn.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMulti_head_attn_CfgInitialize(XMulti_head_attn *InstancePtr, XMulti_head_attn_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMulti_head_attn_Start(XMulti_head_attn *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMulti_head_attn_ReadReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMulti_head_attn_WriteReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMulti_head_attn_IsDone(XMulti_head_attn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMulti_head_attn_ReadReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMulti_head_attn_IsIdle(XMulti_head_attn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMulti_head_attn_ReadReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMulti_head_attn_IsReady(XMulti_head_attn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMulti_head_attn_ReadReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMulti_head_attn_EnableAutoRestart(XMulti_head_attn *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMulti_head_attn_WriteReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMulti_head_attn_DisableAutoRestart(XMulti_head_attn *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMulti_head_attn_WriteReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_AP_CTRL, 0);
}

void XMulti_head_attn_Set_Q(XMulti_head_attn *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMulti_head_attn_WriteReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_Q_DATA, (u32)(Data));
    XMulti_head_attn_WriteReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_Q_DATA + 4, (u32)(Data >> 32));
}

u64 XMulti_head_attn_Get_Q(XMulti_head_attn *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMulti_head_attn_ReadReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_Q_DATA);
    Data += (u64)XMulti_head_attn_ReadReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_Q_DATA + 4) << 32;
    return Data;
}

void XMulti_head_attn_Set_K(XMulti_head_attn *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMulti_head_attn_WriteReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_K_DATA, (u32)(Data));
    XMulti_head_attn_WriteReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_K_DATA + 4, (u32)(Data >> 32));
}

u64 XMulti_head_attn_Get_K(XMulti_head_attn *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMulti_head_attn_ReadReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_K_DATA);
    Data += (u64)XMulti_head_attn_ReadReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_K_DATA + 4) << 32;
    return Data;
}

void XMulti_head_attn_Set_V(XMulti_head_attn *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMulti_head_attn_WriteReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_V_DATA, (u32)(Data));
    XMulti_head_attn_WriteReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_V_DATA + 4, (u32)(Data >> 32));
}

u64 XMulti_head_attn_Get_V(XMulti_head_attn *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMulti_head_attn_ReadReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_V_DATA);
    Data += (u64)XMulti_head_attn_ReadReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_V_DATA + 4) << 32;
    return Data;
}

void XMulti_head_attn_Set_Out_r(XMulti_head_attn *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMulti_head_attn_WriteReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_OUT_R_DATA, (u32)(Data));
    XMulti_head_attn_WriteReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_OUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMulti_head_attn_Get_Out_r(XMulti_head_attn *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMulti_head_attn_ReadReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_OUT_R_DATA);
    Data += (u64)XMulti_head_attn_ReadReg(InstancePtr->Control_r_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_R_ADDR_OUT_R_DATA + 4) << 32;
    return Data;
}

void XMulti_head_attn_InterruptGlobalEnable(XMulti_head_attn *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMulti_head_attn_WriteReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_GIE, 1);
}

void XMulti_head_attn_InterruptGlobalDisable(XMulti_head_attn *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMulti_head_attn_WriteReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_GIE, 0);
}

void XMulti_head_attn_InterruptEnable(XMulti_head_attn *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMulti_head_attn_ReadReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_IER);
    XMulti_head_attn_WriteReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_IER, Register | Mask);
}

void XMulti_head_attn_InterruptDisable(XMulti_head_attn *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMulti_head_attn_ReadReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_IER);
    XMulti_head_attn_WriteReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMulti_head_attn_InterruptClear(XMulti_head_attn *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMulti_head_attn_WriteReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_ISR, Mask);
}

u32 XMulti_head_attn_InterruptGetEnabled(XMulti_head_attn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMulti_head_attn_ReadReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_IER);
}

u32 XMulti_head_attn_InterruptGetStatus(XMulti_head_attn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMulti_head_attn_ReadReg(InstancePtr->Control_BaseAddress, XMULTI_HEAD_ATTN_CONTROL_ADDR_ISR);
}

