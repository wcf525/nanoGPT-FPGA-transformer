// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xmulti_head_attn.h"

extern XMulti_head_attn_Config XMulti_head_attn_ConfigTable[];

#ifdef SDT
XMulti_head_attn_Config *XMulti_head_attn_LookupConfig(UINTPTR BaseAddress) {
	XMulti_head_attn_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XMulti_head_attn_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XMulti_head_attn_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XMulti_head_attn_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMulti_head_attn_Initialize(XMulti_head_attn *InstancePtr, UINTPTR BaseAddress) {
	XMulti_head_attn_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMulti_head_attn_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMulti_head_attn_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XMulti_head_attn_Config *XMulti_head_attn_LookupConfig(u16 DeviceId) {
	XMulti_head_attn_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMULTI_HEAD_ATTN_NUM_INSTANCES; Index++) {
		if (XMulti_head_attn_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMulti_head_attn_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMulti_head_attn_Initialize(XMulti_head_attn *InstancePtr, u16 DeviceId) {
	XMulti_head_attn_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMulti_head_attn_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMulti_head_attn_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

