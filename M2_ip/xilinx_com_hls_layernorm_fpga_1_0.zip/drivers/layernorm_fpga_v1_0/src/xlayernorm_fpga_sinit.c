// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xlayernorm_fpga.h"

extern XLayernorm_fpga_Config XLayernorm_fpga_ConfigTable[];

#ifdef SDT
XLayernorm_fpga_Config *XLayernorm_fpga_LookupConfig(UINTPTR BaseAddress) {
	XLayernorm_fpga_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XLayernorm_fpga_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XLayernorm_fpga_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XLayernorm_fpga_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XLayernorm_fpga_Initialize(XLayernorm_fpga *InstancePtr, UINTPTR BaseAddress) {
	XLayernorm_fpga_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XLayernorm_fpga_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XLayernorm_fpga_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XLayernorm_fpga_Config *XLayernorm_fpga_LookupConfig(u16 DeviceId) {
	XLayernorm_fpga_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XLAYERNORM_FPGA_NUM_INSTANCES; Index++) {
		if (XLayernorm_fpga_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XLayernorm_fpga_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XLayernorm_fpga_Initialize(XLayernorm_fpga *InstancePtr, u16 DeviceId) {
	XLayernorm_fpga_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XLayernorm_fpga_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XLayernorm_fpga_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

