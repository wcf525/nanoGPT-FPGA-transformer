// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xlayernorm_fpga.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLayernorm_fpga_CfgInitialize(XLayernorm_fpga *InstancePtr, XLayernorm_fpga_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLayernorm_fpga_Start(XLayernorm_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayernorm_fpga_ReadReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_AP_CTRL) & 0x80;
    XLayernorm_fpga_WriteReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XLayernorm_fpga_IsDone(XLayernorm_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayernorm_fpga_ReadReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XLayernorm_fpga_IsIdle(XLayernorm_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayernorm_fpga_ReadReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XLayernorm_fpga_IsReady(XLayernorm_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayernorm_fpga_ReadReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XLayernorm_fpga_EnableAutoRestart(XLayernorm_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayernorm_fpga_WriteReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XLayernorm_fpga_DisableAutoRestart(XLayernorm_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayernorm_fpga_WriteReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_AP_CTRL, 0);
}

void XLayernorm_fpga_Set_in_r(XLayernorm_fpga *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayernorm_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XLAYERNORM_FPGA_CONTROL_R_ADDR_IN_R_DATA, (u32)(Data));
    XLayernorm_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XLAYERNORM_FPGA_CONTROL_R_ADDR_IN_R_DATA + 4, (u32)(Data >> 32));
}

u64 XLayernorm_fpga_Get_in_r(XLayernorm_fpga *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayernorm_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XLAYERNORM_FPGA_CONTROL_R_ADDR_IN_R_DATA);
    Data += (u64)XLayernorm_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XLAYERNORM_FPGA_CONTROL_R_ADDR_IN_R_DATA + 4) << 32;
    return Data;
}

void XLayernorm_fpga_Set_out_r(XLayernorm_fpga *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayernorm_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XLAYERNORM_FPGA_CONTROL_R_ADDR_OUT_R_DATA, (u32)(Data));
    XLayernorm_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XLAYERNORM_FPGA_CONTROL_R_ADDR_OUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XLayernorm_fpga_Get_out_r(XLayernorm_fpga *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayernorm_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XLAYERNORM_FPGA_CONTROL_R_ADDR_OUT_R_DATA);
    Data += (u64)XLayernorm_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XLAYERNORM_FPGA_CONTROL_R_ADDR_OUT_R_DATA + 4) << 32;
    return Data;
}

void XLayernorm_fpga_InterruptGlobalEnable(XLayernorm_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayernorm_fpga_WriteReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_GIE, 1);
}

void XLayernorm_fpga_InterruptGlobalDisable(XLayernorm_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayernorm_fpga_WriteReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_GIE, 0);
}

void XLayernorm_fpga_InterruptEnable(XLayernorm_fpga *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLayernorm_fpga_ReadReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_IER);
    XLayernorm_fpga_WriteReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_IER, Register | Mask);
}

void XLayernorm_fpga_InterruptDisable(XLayernorm_fpga *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLayernorm_fpga_ReadReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_IER);
    XLayernorm_fpga_WriteReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_IER, Register & (~Mask));
}

void XLayernorm_fpga_InterruptClear(XLayernorm_fpga *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayernorm_fpga_WriteReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_ISR, Mask);
}

u32 XLayernorm_fpga_InterruptGetEnabled(XLayernorm_fpga *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLayernorm_fpga_ReadReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_IER);
}

u32 XLayernorm_fpga_InterruptGetStatus(XLayernorm_fpga *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLayernorm_fpga_ReadReg(InstancePtr->Control_BaseAddress, XLAYERNORM_FPGA_CONTROL_ADDR_ISR);
}

