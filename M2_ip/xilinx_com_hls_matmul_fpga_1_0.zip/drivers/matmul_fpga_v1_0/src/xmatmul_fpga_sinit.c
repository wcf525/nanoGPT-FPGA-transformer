// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xmatmul_fpga.h"

extern XMatmul_fpga_Config XMatmul_fpga_ConfigTable[];

#ifdef SDT
XMatmul_fpga_Config *XMatmul_fpga_LookupConfig(UINTPTR BaseAddress) {
	XMatmul_fpga_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XMatmul_fpga_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XMatmul_fpga_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XMatmul_fpga_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMatmul_fpga_Initialize(XMatmul_fpga *InstancePtr, UINTPTR BaseAddress) {
	XMatmul_fpga_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMatmul_fpga_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMatmul_fpga_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XMatmul_fpga_Config *XMatmul_fpga_LookupConfig(u16 DeviceId) {
	XMatmul_fpga_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMATMUL_FPGA_NUM_INSTANCES; Index++) {
		if (XMatmul_fpga_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMatmul_fpga_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMatmul_fpga_Initialize(XMatmul_fpga *InstancePtr, u16 DeviceId) {
	XMatmul_fpga_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMatmul_fpga_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMatmul_fpga_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

