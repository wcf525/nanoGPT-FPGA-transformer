// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmatmul_fpga.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMatmul_fpga_CfgInitialize(XMatmul_fpga *InstancePtr, XMatmul_fpga_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMatmul_fpga_Start(XMatmul_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_fpga_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMatmul_fpga_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMatmul_fpga_IsDone(XMatmul_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_fpga_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMatmul_fpga_IsIdle(XMatmul_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_fpga_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMatmul_fpga_IsReady(XMatmul_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_fpga_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMatmul_fpga_EnableAutoRestart(XMatmul_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_fpga_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMatmul_fpga_DisableAutoRestart(XMatmul_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_fpga_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_AP_CTRL, 0);
}

void XMatmul_fpga_Set_A(XMatmul_fpga *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_A_DATA, (u32)(Data));
    XMatmul_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_A_DATA + 4, (u32)(Data >> 32));
}

u64 XMatmul_fpga_Get_A(XMatmul_fpga *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_A_DATA);
    Data += (u64)XMatmul_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_A_DATA + 4) << 32;
    return Data;
}

void XMatmul_fpga_Set_B(XMatmul_fpga *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_B_DATA, (u32)(Data));
    XMatmul_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_B_DATA + 4, (u32)(Data >> 32));
}

u64 XMatmul_fpga_Get_B(XMatmul_fpga *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_B_DATA);
    Data += (u64)XMatmul_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_B_DATA + 4) << 32;
    return Data;
}

void XMatmul_fpga_Set_C(XMatmul_fpga *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_C_DATA, (u32)(Data));
    XMatmul_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_C_DATA + 4, (u32)(Data >> 32));
}

u64 XMatmul_fpga_Get_C(XMatmul_fpga *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_C_DATA);
    Data += (u64)XMatmul_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XMATMUL_FPGA_CONTROL_R_ADDR_C_DATA + 4) << 32;
    return Data;
}

void XMatmul_fpga_InterruptGlobalEnable(XMatmul_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_fpga_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_GIE, 1);
}

void XMatmul_fpga_InterruptGlobalDisable(XMatmul_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_fpga_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_GIE, 0);
}

void XMatmul_fpga_InterruptEnable(XMatmul_fpga *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMatmul_fpga_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_IER);
    XMatmul_fpga_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_IER, Register | Mask);
}

void XMatmul_fpga_InterruptDisable(XMatmul_fpga *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMatmul_fpga_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_IER);
    XMatmul_fpga_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMatmul_fpga_InterruptClear(XMatmul_fpga *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_fpga_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_ISR, Mask);
}

u32 XMatmul_fpga_InterruptGetEnabled(XMatmul_fpga *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMatmul_fpga_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_IER);
}

u32 XMatmul_fpga_InterruptGetStatus(XMatmul_fpga *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMatmul_fpga_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_FPGA_CONTROL_ADDR_ISR);
}

