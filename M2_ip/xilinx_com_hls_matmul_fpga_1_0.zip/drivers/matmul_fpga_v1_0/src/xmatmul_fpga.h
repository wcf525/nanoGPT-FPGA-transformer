// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMATMUL_FPGA_H
#define XMATMUL_FPGA_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmatmul_fpga_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XMatmul_fpga_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XMatmul_fpga;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMatmul_fpga_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMatmul_fpga_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMatmul_fpga_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMatmul_fpga_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XMatmul_fpga_Initialize(XMatmul_fpga *InstancePtr, UINTPTR BaseAddress);
XMatmul_fpga_Config* XMatmul_fpga_LookupConfig(UINTPTR BaseAddress);
#else
int XMatmul_fpga_Initialize(XMatmul_fpga *InstancePtr, u16 DeviceId);
XMatmul_fpga_Config* XMatmul_fpga_LookupConfig(u16 DeviceId);
#endif
int XMatmul_fpga_CfgInitialize(XMatmul_fpga *InstancePtr, XMatmul_fpga_Config *ConfigPtr);
#else
int XMatmul_fpga_Initialize(XMatmul_fpga *InstancePtr, const char* InstanceName);
int XMatmul_fpga_Release(XMatmul_fpga *InstancePtr);
#endif

void XMatmul_fpga_Start(XMatmul_fpga *InstancePtr);
u32 XMatmul_fpga_IsDone(XMatmul_fpga *InstancePtr);
u32 XMatmul_fpga_IsIdle(XMatmul_fpga *InstancePtr);
u32 XMatmul_fpga_IsReady(XMatmul_fpga *InstancePtr);
void XMatmul_fpga_EnableAutoRestart(XMatmul_fpga *InstancePtr);
void XMatmul_fpga_DisableAutoRestart(XMatmul_fpga *InstancePtr);

void XMatmul_fpga_Set_A(XMatmul_fpga *InstancePtr, u64 Data);
u64 XMatmul_fpga_Get_A(XMatmul_fpga *InstancePtr);
void XMatmul_fpga_Set_B(XMatmul_fpga *InstancePtr, u64 Data);
u64 XMatmul_fpga_Get_B(XMatmul_fpga *InstancePtr);
void XMatmul_fpga_Set_C(XMatmul_fpga *InstancePtr, u64 Data);
u64 XMatmul_fpga_Get_C(XMatmul_fpga *InstancePtr);

void XMatmul_fpga_InterruptGlobalEnable(XMatmul_fpga *InstancePtr);
void XMatmul_fpga_InterruptGlobalDisable(XMatmul_fpga *InstancePtr);
void XMatmul_fpga_InterruptEnable(XMatmul_fpga *InstancePtr, u32 Mask);
void XMatmul_fpga_InterruptDisable(XMatmul_fpga *InstancePtr, u32 Mask);
void XMatmul_fpga_InterruptClear(XMatmul_fpga *InstancePtr, u32 Mask);
u32 XMatmul_fpga_InterruptGetEnabled(XMatmul_fpga *InstancePtr);
u32 XMatmul_fpga_InterruptGetStatus(XMatmul_fpga *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
