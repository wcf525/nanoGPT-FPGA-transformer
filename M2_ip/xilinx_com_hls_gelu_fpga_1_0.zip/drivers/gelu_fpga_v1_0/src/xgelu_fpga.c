// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xgelu_fpga.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XGelu_fpga_CfgInitialize(XGelu_fpga *InstancePtr, XGelu_fpga_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XGelu_fpga_Start(XGelu_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGelu_fpga_ReadReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_AP_CTRL) & 0x80;
    XGelu_fpga_WriteReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XGelu_fpga_IsDone(XGelu_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGelu_fpga_ReadReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XGelu_fpga_IsIdle(XGelu_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGelu_fpga_ReadReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XGelu_fpga_IsReady(XGelu_fpga *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGelu_fpga_ReadReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XGelu_fpga_EnableAutoRestart(XGelu_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGelu_fpga_WriteReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XGelu_fpga_DisableAutoRestart(XGelu_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGelu_fpga_WriteReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_AP_CTRL, 0);
}

void XGelu_fpga_Set_in_r(XGelu_fpga *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGelu_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XGELU_FPGA_CONTROL_R_ADDR_IN_R_DATA, (u32)(Data));
    XGelu_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XGELU_FPGA_CONTROL_R_ADDR_IN_R_DATA + 4, (u32)(Data >> 32));
}

u64 XGelu_fpga_Get_in_r(XGelu_fpga *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGelu_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XGELU_FPGA_CONTROL_R_ADDR_IN_R_DATA);
    Data += (u64)XGelu_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XGELU_FPGA_CONTROL_R_ADDR_IN_R_DATA + 4) << 32;
    return Data;
}

void XGelu_fpga_Set_out_r(XGelu_fpga *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGelu_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XGELU_FPGA_CONTROL_R_ADDR_OUT_R_DATA, (u32)(Data));
    XGelu_fpga_WriteReg(InstancePtr->Control_r_BaseAddress, XGELU_FPGA_CONTROL_R_ADDR_OUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XGelu_fpga_Get_out_r(XGelu_fpga *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGelu_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XGELU_FPGA_CONTROL_R_ADDR_OUT_R_DATA);
    Data += (u64)XGelu_fpga_ReadReg(InstancePtr->Control_r_BaseAddress, XGELU_FPGA_CONTROL_R_ADDR_OUT_R_DATA + 4) << 32;
    return Data;
}

void XGelu_fpga_InterruptGlobalEnable(XGelu_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGelu_fpga_WriteReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_GIE, 1);
}

void XGelu_fpga_InterruptGlobalDisable(XGelu_fpga *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGelu_fpga_WriteReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_GIE, 0);
}

void XGelu_fpga_InterruptEnable(XGelu_fpga *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGelu_fpga_ReadReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_IER);
    XGelu_fpga_WriteReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_IER, Register | Mask);
}

void XGelu_fpga_InterruptDisable(XGelu_fpga *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGelu_fpga_ReadReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_IER);
    XGelu_fpga_WriteReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_IER, Register & (~Mask));
}

void XGelu_fpga_InterruptClear(XGelu_fpga *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGelu_fpga_WriteReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_ISR, Mask);
}

u32 XGelu_fpga_InterruptGetEnabled(XGelu_fpga *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGelu_fpga_ReadReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_IER);
}

u32 XGelu_fpga_InterruptGetStatus(XGelu_fpga *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGelu_fpga_ReadReg(InstancePtr->Control_BaseAddress, XGELU_FPGA_CONTROL_ADDR_ISR);
}

