// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XGELU_FPGA_H
#define XGELU_FPGA_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xgelu_fpga_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XGelu_fpga_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XGelu_fpga;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XGelu_fpga_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XGelu_fpga_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XGelu_fpga_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XGelu_fpga_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XGelu_fpga_Initialize(XGelu_fpga *InstancePtr, UINTPTR BaseAddress);
XGelu_fpga_Config* XGelu_fpga_LookupConfig(UINTPTR BaseAddress);
#else
int XGelu_fpga_Initialize(XGelu_fpga *InstancePtr, u16 DeviceId);
XGelu_fpga_Config* XGelu_fpga_LookupConfig(u16 DeviceId);
#endif
int XGelu_fpga_CfgInitialize(XGelu_fpga *InstancePtr, XGelu_fpga_Config *ConfigPtr);
#else
int XGelu_fpga_Initialize(XGelu_fpga *InstancePtr, const char* InstanceName);
int XGelu_fpga_Release(XGelu_fpga *InstancePtr);
#endif

void XGelu_fpga_Start(XGelu_fpga *InstancePtr);
u32 XGelu_fpga_IsDone(XGelu_fpga *InstancePtr);
u32 XGelu_fpga_IsIdle(XGelu_fpga *InstancePtr);
u32 XGelu_fpga_IsReady(XGelu_fpga *InstancePtr);
void XGelu_fpga_EnableAutoRestart(XGelu_fpga *InstancePtr);
void XGelu_fpga_DisableAutoRestart(XGelu_fpga *InstancePtr);

void XGelu_fpga_Set_in_r(XGelu_fpga *InstancePtr, u64 Data);
u64 XGelu_fpga_Get_in_r(XGelu_fpga *InstancePtr);
void XGelu_fpga_Set_out_r(XGelu_fpga *InstancePtr, u64 Data);
u64 XGelu_fpga_Get_out_r(XGelu_fpga *InstancePtr);

void XGelu_fpga_InterruptGlobalEnable(XGelu_fpga *InstancePtr);
void XGelu_fpga_InterruptGlobalDisable(XGelu_fpga *InstancePtr);
void XGelu_fpga_InterruptEnable(XGelu_fpga *InstancePtr, u32 Mask);
void XGelu_fpga_InterruptDisable(XGelu_fpga *InstancePtr, u32 Mask);
void XGelu_fpga_InterruptClear(XGelu_fpga *InstancePtr, u32 Mask);
u32 XGelu_fpga_InterruptGetEnabled(XGelu_fpga *InstancePtr);
u32 XGelu_fpga_InterruptGetStatus(XGelu_fpga *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
