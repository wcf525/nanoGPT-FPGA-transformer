// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xgelu_fpga.h"

extern XGelu_fpga_Config XGelu_fpga_ConfigTable[];

#ifdef SDT
XGelu_fpga_Config *XGelu_fpga_LookupConfig(UINTPTR BaseAddress) {
	XGelu_fpga_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XGelu_fpga_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XGelu_fpga_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XGelu_fpga_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGelu_fpga_Initialize(XGelu_fpga *InstancePtr, UINTPTR BaseAddress) {
	XGelu_fpga_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGelu_fpga_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGelu_fpga_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XGelu_fpga_Config *XGelu_fpga_LookupConfig(u16 DeviceId) {
	XGelu_fpga_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XGELU_FPGA_NUM_INSTANCES; Index++) {
		if (XGelu_fpga_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XGelu_fpga_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGelu_fpga_Initialize(XGelu_fpga *InstancePtr, u16 DeviceId) {
	XGelu_fpga_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGelu_fpga_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGelu_fpga_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

